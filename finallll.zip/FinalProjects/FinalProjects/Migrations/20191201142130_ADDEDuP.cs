﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FinalProjects.Migrations
{
    public partial class ADDEDuP : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Genders_GenderId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "GenderİD",
                table: "AspNetUsers");

            migrationBuilder.RenameColumn(
                name: "GenderId",
                table: "AspNetUsers",
                newName: "GenderID");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_GenderId",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_GenderID");

            migrationBuilder.AlterColumn<int>(
                name: "GenderID",
                table: "AspNetUsers",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Genders_GenderID",
                table: "AspNetUsers",
                column: "GenderID",
                principalTable: "Genders",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Genders_GenderID",
                table: "AspNetUsers");

            migrationBuilder.RenameColumn(
                name: "GenderID",
                table: "AspNetUsers",
                newName: "GenderId");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_GenderID",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_GenderId");

            migrationBuilder.AlterColumn<int>(
                name: "GenderId",
                table: "AspNetUsers",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddColumn<int>(
                name: "GenderİD",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Genders_GenderId",
                table: "AspNetUsers",
                column: "GenderId",
                principalTable: "Genders",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
