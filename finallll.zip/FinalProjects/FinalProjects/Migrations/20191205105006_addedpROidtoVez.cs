﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FinalProjects.Migrations
{
    public partial class addedpROidtoVez : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "VezID",
                table: "Products",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
           
        }
    }
}
