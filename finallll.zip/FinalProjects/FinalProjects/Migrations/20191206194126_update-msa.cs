﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FinalProjects.Migrations
{
    public partial class updatemsa : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Messages_TexnikiDestekID",
                table: "Messages",
                column: "TexnikiDestekID");

            migrationBuilder.AddForeignKey(
                name: "FK_Messages_TexnikiDesteks_TexnikiDestekID",
                table: "Messages",
                column: "TexnikiDestekID",
                principalTable: "TexnikiDesteks",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
          
        }
    }
}
