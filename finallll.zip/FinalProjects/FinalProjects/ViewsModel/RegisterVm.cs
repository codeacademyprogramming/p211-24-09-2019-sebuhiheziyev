﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FinalProjects.ViewsModel
{
    public class RegisterVm
    {
        [Required(ErrorMessage = "Email doldurulmalıdır ")]
        [MinLength(5)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "İstifadəçi adı doldurulmalıdır")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Ad doldurulmalıdır")]
        [MinLength(3)]
        public string FirstName { get; set; }

        public string LastName { get; set; }


        [Required(ErrorMessage = "Şifrə doldurulmalıdır")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required, Compare(nameof(Password))]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}
