﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using FinalProjects.DAL;
using FinalProjects.Models;

namespace FinalProjects.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class SupportController : Controller
    {
        private readonly FrontContext _context;

        public SupportController(FrontContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            ViewData["status"] = _context.Veziyyets.ToList();
            var txnkDestek = _context.TexnikiDesteks.ToList();
            return View(txnkDestek);
            
        }
        
        public IActionResult Chat(int? id)
        {
            if (id == null) return NotFound();
            ViewData["destek"] = _context.TexnikiDesteks.Find(id);
            ViewData["sms"] = _context.Messages.Where(m => m.TexnikiDestekID == id).ToList();
            
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Chat(int id, Message message)
        {
            if (!ModelState.IsValid)
            {
                return View(message);
            }
            ViewData["sms"] = _context.Messages.Where(m => m.TexnikiDestekID == id).ToList();


            Message ms = new Message
            {
                Msj = message.Msj,
                TexnikiDestekID = id,
                UserID = "admin",
                CreatedAT = DateTime.Now
            };

            TexnikiDestek destek = _context.TexnikiDesteks.Find(id);
            destek.VezID = 4;

            await _context.Messages.AddAsync(ms);

            await _context.SaveChangesAsync();

            return RedirectToAction("Chat", "Support","Admin");
        }


    }
}