﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.DAL;
using FinalProjects.Models;
using Microsoft.AspNetCore.Authorization;


namespace FinalProjects.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class SubCategoryController : Controller
    {
        private readonly FrontContext _context;

        public SubCategoryController(FrontContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var subCategory = _context.Subcategories.ToList();
            ViewData["category"] = _context.Categories.ToList();

            return View(subCategory);
        }

        public async Task<IActionResult> Edit(int? id)
        {

            if (id == null) return NotFound();
            ViewData["category"] = _context.Categories.ToList();

            var subcategory = await _context.Subcategories.FindAsync(id);

            if (subcategory == null) return NotFound();


            return View(subcategory);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Subcategory subcategory)
        {
            if (!ModelState.IsValid) return View(subcategory);

            Subcategory  SubcaetgoryFromDb = await _context.Subcategories.FindAsync(id);

            

            SubcaetgoryFromDb.Name = subcategory.Name;
            SubcaetgoryFromDb.CategoryID = subcategory.CategoryID;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }

        public IActionResult Create()
        {
            ViewData["category"] = _context.Categories.ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Subcategory subcategory)
        {
            ViewData["category"] = _context.Categories.ToList();

            if (!ModelState.IsValid)
            {
                return View(subcategory);
            }

            await _context.Subcategories.AddAsync(subcategory);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult> Delet(int? id)
        {

            if (id == null) return NotFound();

            var subcategory = await _context.Subcategories.FindAsync(id);

            if (subcategory == null) return NotFound();
            ViewData["category"] = _context.Categories.ToList();

            return View(subcategory);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delet")]
        public async Task<IActionResult> DeletSubcategory(int? id)
        {
            if (id == null) return NotFound();

            var subcategory = await _context.Subcategories.FindAsync(id);

            if (subcategory == null) return NotFound();


            _context.Subcategories.Remove(subcategory);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }
    }
}