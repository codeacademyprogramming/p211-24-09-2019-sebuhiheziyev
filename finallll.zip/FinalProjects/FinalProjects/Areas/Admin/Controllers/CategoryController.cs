﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjects.DAL;
using FinalProjects.Extensions;
using FinalProjects.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using static FinalProjects.Utilities.Utilities;
using Microsoft.AspNetCore.Authorization;



namespace FinalProjects.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class CategoryController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;

        public CategoryController(FrontContext context, IHostingEnvironment env )
        {
            _context = context;
            _env = env;
        }

        public IActionResult Index()
        {
            var category =  _context.Categories.ToList();

            return View(category);
        }

        public async Task<IActionResult> Edit(int? id)
        {

            if (id == null) return NotFound();

            var category = await _context.Categories.FindAsync(id);

            if (category == null) return NotFound();


            return View(category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Category category)
        {
            if (!ModelState.IsValid) return View(category);

            Category caetgoryFromDb = await _context.Categories.FindAsync(id);

            if (category.Photo != null)
            {
                if (category.Photo.IsImage())
                {
                    string path = _env.WebRootPath + @"\img\" + caetgoryFromDb.Image;
                    RemoveFile(path);

                    caetgoryFromDb.Image = await category.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                    return View(category);
                }

            }

            caetgoryFromDb.Name = category.Name;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category)
        {
            if (!ModelState.IsValid)
            {
                return View(category);
            }
            if (category.Photo == null)
            {
                ModelState.AddModelError("Photo", "Sekil mutleq secilmedlir");
                return View(category);
            }

            if (!category.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                return View(category);
            }

            category.Image = await category.Photo.SaveFileAsync(_env.WebRootPath);
            await _context.Categories.AddAsync(category);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Delet(int? id)
        {

            if (id == null) return NotFound();

            var category = await _context.Categories.FindAsync(id);

            if (category == null) return NotFound();


            return View(category);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delet")]
        public async Task<IActionResult> DeletCategory(int? id)
        {
            if (id == null) return NotFound();

            var category = await _context.Categories.FindAsync(id);

            if (category == null) return NotFound();

            string path = _env.WebRootPath + @"\img\" + category.Image;
            RemoveFile(path);

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }

    }
}