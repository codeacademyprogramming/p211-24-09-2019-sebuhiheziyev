﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FinalProjects.Models
{
    public class Message
    {
        public int Id { get; set; }
        public string Msj { get; set; }
        public string UserID { get; set; }
        public int TexnikiDestekID { get; set; }
        public DateTime CreatedAT { get; set; }
        public virtual TexnikiDestek TexnikiDestek { get; set; }
    }
}
