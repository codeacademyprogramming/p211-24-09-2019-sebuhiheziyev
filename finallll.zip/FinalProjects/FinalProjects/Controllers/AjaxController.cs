﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjects.DAL;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.ViewsModel;
using FinalProjects.Models;
using FinalProjects.Extensions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using static FinalProjects.Utilities.Utilities;
using Microsoft.AspNetCore.Hosting.Internal;

namespace FinalProjects.Controllers
{
    public class AjaxController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;


        public AjaxController(FrontContext context, HostingEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Marka(int id)
        {
            var list = _context.Subcategories.Where(dc => dc.CategoryID == id)
                .Select(sc => new { sc.Id, sc.Name });
            return Ok(new
            {
                data = list
            });
        }

        public async Task<IActionResult> ProductRemove(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products.FindAsync(id);

            if (product == null) return NotFound();

            foreach (var img in _context.ProductImages)
            {
                if (img.ProductID == product.Id)
                {
                    ProductImage productImageDeletDt = img;
                    string path = _env.WebRootPath + @"\img\" + productImageDeletDt.Name;
                    RemoveFile(path);

                    _context.ProductImages.Remove(productImageDeletDt);
                }
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                data = ""
            });
        }
    }
}