﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.Models;
using FinalProjects.DAL;
using FinalProjects.ViewsModel;
using Microsoft.AspNetCore.Identity;
using FinalProjects.Extensions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authorization;
using static FinalProjects.Utilities.Utilities;


namespace FinalProjects.Controllers
{
    public class AccountController : Controller
    {

        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;
        private readonly IHostingEnvironment _env;

        public AccountController(FrontContext context, UserManager<AppUser> userManager, IHostingEnvironment env)
        {
            _context = context;
            _userManager = userManager;
            _env = env;
        }

        public async Task<IActionResult> Settings()
        {
            string name = User.Identity.Name;
            AppUser appUser = await _userManager.FindByNameAsync(name);
            AccountVm user = new AccountVm();
            user.FirstName = appUser.FirstName;
            user.LastName = appUser.LastName;
            user.Image = appUser.Image;
            user.BrithDate = appUser.BrithDate;
            
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Settings(AppUser appUser)
        {
            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);

            if (!ModelState.IsValid)
            {
                return View(appUser);
            }

            if (appUser.Photo != null)
            {
                if (!appUser.Photo.IsImage())
                {
                    ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                    return View(appUser);

                }
                if (activUser.Image == null)
                {
                    activUser.Image = await appUser.Photo.SaveFileAsync(_env.WebRootPath);

                }
                else
                {
                    string path = _env.WebRootPath + @"\img\" + activUser.Image;
                    RemoveFile(path);
                    activUser.Image = await appUser.Photo.SaveFileAsync(_env.WebRootPath);
                }
            }

            activUser.FirstName = appUser.FirstName;
            activUser.LastName = appUser.LastName;
            activUser.BrithDate = appUser.BrithDate;

            await _userManager.UpdateAsync(activUser);

            return RedirectToAction("Index", "Home");

        }

        public async Task<IActionResult> MyProduct()
        {
            string name = User.Identity.Name;
            AppUser appUser = await _userManager.FindByNameAsync(name);

            ViewData["imgProdut"] = _context.ProductImages.ToList();
            ViewData["status"] = _context.Veziyyets.ToList();


            List<Product> products = _context.Products.OrderByDescending(d=>d.CreatedAt).Where(p => p.AppuserID == appUser.Id).ToList();


            return View(products);
        }
    }
} 