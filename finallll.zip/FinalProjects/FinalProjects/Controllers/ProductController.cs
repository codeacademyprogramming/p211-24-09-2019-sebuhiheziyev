﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.Models;
using FinalProjects.DAL;
using FinalProjects.ViewsModel;
using Microsoft.AspNetCore.Identity;
using FinalProjects.Extensions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authorization;
using static FinalProjects.Utilities.Utilities;


namespace FinalProjects.Controllers
{
    public class ProductController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;
        private readonly IHostingEnvironment _env;
        AppUser appUser;


        public ProductController(FrontContext context, UserManager<AppUser> userManager, IHostingEnvironment env)
        {
            _context = context;
            _userManager = userManager;
            _env = env;
        }



        public async Task<IActionResult> Show(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products.FindAsync(id);

            if (product == null) return NotFound();

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                appUser = await _userManager.FindByNameAsync(name);
            }
            ProductVm productVm = new ProductVm
            {
                Product = product,
                Cities = _context.Cities.ToList(),
                Subcategories = _context.Subcategories.ToList(),
                Categories = _context.Categories.ToList(),
                ProductImages = _context.ProductImages.ToList(),
                AppUser = appUser
            };
            product.SeeCount += 1;
            await  _context.SaveChangesAsync();
            return View(productVm);
        }

        public async Task<IActionResult> Update(int? id)
        {

            ViewData["items"] = _context.Categories.ToList();
            ViewData["items2"] = _context.Cities.ToList();

            if (id == null) return NotFound();

            var product = await _context.Products.FindAsync(id);

            if (product == null) return NotFound();

            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);

            if (product.AppuserID != activUser.Id)
            {
                return NotFound();
            }


            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id,Product productOld)
        {

            ViewData["items"] = _context.Categories.ToList();
            ViewData["items2"] = _context.Cities.ToList();

            Product upProduct = await _context.Products.FindAsync(id);
            if (!ModelState.IsValid)
            {
                return View(productOld);
            }

            if (productOld.Photos != null)
            {
                foreach (var formFileImg in productOld.Photos)
                {
                    if (formFileImg.IsImage())
                    {
                        ProductImage productImges = new ProductImage();
                        productImges.Name = await formFileImg.SaveFileAsync(_env.WebRootPath);
                        productImges.ProductID = productOld.Id;
                        await _context.ProductImages.AddAsync(productImges);
                    }
                    else
                    {
                        ModelState.AddModelError("Photos", "sekil duzgun secilmedlir");
                        return View(productOld);
                    }
                }
            }

            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);



            upProduct.AppuserID = activUser.Id;
            upProduct.Name = productOld.Name;
            upProduct.SubcategoryID = productOld.SubcategoryID;
            upProduct.Price = productOld.Price;
            upProduct.Number = productOld.Number;
            upProduct.CityID = productOld.CityID;
            upProduct.Description = productOld.Description;
            upProduct.Email = productOld.Email;
            upProduct.Head = productOld.Head;
            upProduct.UpdateAt = DateTime.Now;


            await _context.SaveChangesAsync();
            return RedirectToAction("MyProduct", "Account");
        }


    }
}