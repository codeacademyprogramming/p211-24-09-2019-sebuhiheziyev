﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalProjects.ViewsModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using FinalProjects.Models;
using FinalProjects.DAL;

namespace FinalProjects.Controllers
{
    public class AuthController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;


        public AuthController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager,FrontContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterVm registerVm)
        {

            if (!ModelState.IsValid)
            {
                return View(registerVm);
            }

            AppUser appUser = new AppUser
            {
                Email = registerVm.Email,
                UserName = registerVm.Username,
                FirstName = registerVm.FirstName,
                LastName = registerVm.LastName,
            };



             IdentityResult result = await  _userManager.CreateAsync(appUser, registerVm.Password);

            if (result.Succeeded)
            {
                return RedirectToAction(nameof(Login));

            }
            else
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
                return View(registerVm);

            }

        }

        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginVm loginVm)
        {
            if (!ModelState.IsValid) return View(loginVm);

            AppUser user = await _userManager.FindByEmailAsync(loginVm.Email);

            if (user == null)
            {
                ModelState.AddModelError("", "Email ve ya parol səfdi");
                return View(loginVm);
            }

            var result = await _signInManager.PasswordSignInAsync(user, loginVm.Password, loginVm.RememberMe, true);

            if (result.Succeeded)
            {
                return RedirectToAction("Index", "Home");
            }


            ModelState.AddModelError("", "Email ve ya parol sefdi");
            return View(loginVm);
        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();

            return RedirectToAction("Index", "Home");

        }
    }
}