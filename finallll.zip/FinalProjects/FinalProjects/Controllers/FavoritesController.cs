﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinalProjects.Models;
using FinalProjects.DAL;
using FinalProjects.ViewsModel;
using Microsoft.AspNetCore.Identity;

namespace FinalProjects.Controllers
{
    public class FavoritesController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;


        public FavoritesController(FrontContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Add(int id)
        {
            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);
            List<FavoriteProduct> product =  _context.FavoriteProducts.Where(p => p.ProductID == id && p.AppuserID == activUser.Id).ToList();

            if (product.Count > 0)
            {
                foreach (var pro in product)
                {
                    _context.FavoriteProducts.Remove(pro);
                }
            }
            else
            {
                FavoriteProduct favoriteProduct = new FavoriteProduct();
                favoriteProduct.AppuserID = activUser.Id;
                favoriteProduct.ProductID = id;
                await _context.FavoriteProducts.AddAsync(favoriteProduct);
            }

            await _context.SaveChangesAsync();

            return Ok(new
            {
                status =200,
                error ="",
                data =""
            });
        }

        public async Task<IActionResult> Index()
        {
            AppUser activUser = await _userManager.FindByNameAsync(User.Identity.Name);


            HomeIndexVm homeIndexVm = new HomeIndexVm
            {
                Products = _context.Products.ToList(),
                ProductImages = _context.ProductImages.ToList(),
                FavoriteProducts = _context.FavoriteProducts.ToList(),
                AppUser = activUser
            };


            return View(homeIndexVm);
        }
    }
}