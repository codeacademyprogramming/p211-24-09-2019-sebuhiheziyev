﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FinalProjects.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace FinalProjects.DAL
{
    public class FrontContext : IdentityDbContext<AppUser>
    {
        public FrontContext(DbContextOptions<FrontContext> options) : base(options)
        {
        }

        public DbSet<TermsItem> TermsItems { get; set; }
        public DbSet<Terms> Terms { get; set; }
        public DbSet<City> Cities { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Subcategory> Subcategories { get; set; } 
        public DbSet<ProductImage> ProductImages { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<FavoriteProduct> FavoriteProducts { get; set; }
        public DbSet<Veziyyet> Veziyyets { get; set; }
        public DbSet<TexnikiDestek> TexnikiDesteks { get; set; }
        public DbSet<Message> Messages { get; set; }
    }
}
