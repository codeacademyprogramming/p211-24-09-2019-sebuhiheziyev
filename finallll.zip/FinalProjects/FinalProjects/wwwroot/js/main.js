﻿
const maxPriceValue = document.getElementsByClassName("txt-max-price")[0];
const minPriceValue = document.getElementsByClassName("txt-min-price")[0];



$("#max-price").change(function(){
    maxPriceValue.innerText = this.value;
});

$("#min-price").change(function(){
    minPriceValue.innerText = this.value;
});


$(".setting-table-item-head").click(function(){
    $(this).next().toggleClass("setting-table-active-item");
    $(this).find("i").toggleClass("active-icon");
});

$(".phone-icon").click(function(){
    $(".user-phone-fon").toggleClass("d-none");
});

$(".go-top").click(function () {
    $('html, body').animate({ scrollTop: 0 }, 1000);
    return false;
});

window.onload = function () {

    $("#loading").addClass("hide");
    setTimeout(() => {
        $("#loading").addClass("d-none");
    }, 300);
};

 // plugin carusel
 $(document).ready(function(){
    $(".owl-carousel").owlCarousel();


  });



  $('.oc-1').owlCarousel({
      loop: true,
      nav:true,
      margin: 10,
      dots: true,
      autoplay:true,
      autoplayTimeout:1000,
      responsive: {
          0: {
              items: 2,
          },
          600: {
              items: 5,
          },
          1000: {
              items: 5
          }
      }
  })

$('#category').change(function (e) {
    let id = $(this).val();
    $('.sb-cat-form').removeClass('sb-cat');
    $.ajax({
        url: "/Ajax/Marka/" + id,
        method: "GET",
        success: function (respons) {
            $('#subcat').empty();
            $('#subcat').append('<option id="delet-subcat">' + "Məhsul növünü seçin" + '</option>');
            respons.data.forEach((sc) => {
                $('#subcat').append('<option value=' + sc.id + '>' + sc.name + '</option>')
            });
        }
    });
});

$('#subcat').change(function () {
    $('#delet-subcat').remove();
});


$(".product-fav-icon").click(function (e) {
    e.preventDefault();
    $(this).children('.heart-js').toggleClass('activ-heart');
    //$(this).attr('hearts', '1');
       $.ajax({
            url: $(this).attr("href"),
            method: "GET",
            success: function (res) {
                
            }
        });
});

$('.remove-show-delet').click(function (e) {
    e.preventDefault();
    $('.remove-yes-no-area').removeClass('d-none');
});

$('.no-remove').click(function (e) {
    e.preventDefault();
    $('.remove-yes-no-area').addClass('d-none');
});

$('.yes-remove').click(function (e) {
    e.preventDefault();
    $.ajax({
        url: $(this).attr("href"),
        method: "GET",
        success: function (res) {
            window.location.reload();
        }
    });
});



