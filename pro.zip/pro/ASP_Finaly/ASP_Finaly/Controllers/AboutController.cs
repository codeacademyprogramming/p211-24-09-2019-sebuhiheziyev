﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.Models;
using ASP_Finaly.DAL;
using ASP_Finaly.ViewsModels;


namespace ASP_Finaly.Controllers
{

    public class AboutController : Controller
    {
        private readonly FrontContext _context;
        public AboutController(FrontContext context)
        {
            _context = context;
        }
            
        public IActionResult Index()
        {
            HomeIndexVm homeIndexVm = new HomeIndexVm
            {
                Facts = _context.Facts.ToList(),
                Customers = _context.Customers.ToList(),
                Teams = _context.Teams.ToList()
            };

            return View(homeIndexVm);
        }
    }
}