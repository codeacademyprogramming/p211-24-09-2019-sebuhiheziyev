﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.Models;
using ASP_Finaly.DAL;
using ASP_Finaly.ViewsModels;


namespace ASP_Finaly.Controllers
{
    public class ProjectController : Controller
    {
        private readonly FrontContext _context;
        public ProjectController(FrontContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            HomeIndexVm homeIndexVm = new HomeIndexVm
            {
               Projects = _context.Projects.ToList()
            };

            return View(homeIndexVm);
        }
    }
}