﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.ViewsModels;
using Microsoft.AspNetCore.Identity;
using ASP_Finaly.Models;

namespace ASP_Finaly.Controllers
{
    public class AuthController : Controller
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;

        public AuthController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager )
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterVm registerVm)
        {
            if (!ModelState.IsValid)
            {
                return View(registerVm);
            }

            AppUser appUser = new AppUser
            {
                Email = registerVm.Email,
                UserName = registerVm.Username,
                FirstName = registerVm.FirstName,
                LastName = registerVm.LastName,
            };

            IdentityResult result =  await  _userManager.CreateAsync(appUser,registerVm.Password);

            if (result.Succeeded)
            {
                return RedirectToAction(nameof(Login));

            }
            else
            {
                foreach (IdentityError error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
                return View(registerVm);
            }

        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async  Task<IActionResult> Login(LoginVm loginVm)
        {
            if (!ModelState.IsValid) return View(loginVm);

            AppUser user = await _userManager.FindByEmailAsync(loginVm.Email);

            if (user == null)
            {
                ModelState.AddModelError("", "Email ve ya parol sefdi");
                return View(loginVm);
            }

            var result = await _signInManager.PasswordSignInAsync(user,loginVm.Password, loginVm.RememberMe,true);

            if (result.Succeeded)
            {
                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Email ve ya parol sefdi");
            return View(loginVm);
        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");

        }

    }
}