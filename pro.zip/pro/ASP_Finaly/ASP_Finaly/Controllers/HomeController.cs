﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.Models;
using ASP_Finaly.DAL;
using ASP_Finaly.ViewsModels;

namespace ASP_Finaly.Controllers
{
    public class HomeController : Controller
    {
        private readonly FrontContext _context;

        public HomeController(FrontContext context)
        {
            _context = context;
        }


        public IActionResult Index()
        {
            HomeIndexVm homeIndexVm = new HomeIndexVm
            {
                Sliders = _context.Sliders.ToList(),
                Facts = _context.Facts.ToList(),
                Projects = _context.Projects.ToList(),
                Customers = _context.Customers.ToList(),
                Teams = _context.Teams.ToList()
            };

            return View(homeIndexVm);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
