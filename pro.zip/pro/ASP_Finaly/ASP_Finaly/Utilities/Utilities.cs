﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace ASP_Finaly.Utilities
{
    public static class Utilities
    {
        public static void RemoveFile(string path)
        {
            if(File.Exists(path))
            {
                File.Delete(path);
            }
        }
    }
}
