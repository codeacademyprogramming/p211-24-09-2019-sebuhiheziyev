﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASP_Finaly.DAL;
using ASP_Finaly.Models;

namespace ASP_Finaly.ViewsModels
{
    public class HomeIndexVm
    {
        public IEnumerable<Slider> Sliders { get; set; }

        public IEnumerable<Fact> Facts { get; set; }

        public IEnumerable<Project> Projects { get; set; }

        public IEnumerable<Customer> Customers { get; set; }

        public IEnumerable<Team> Teams { get; set; }

    }
}
