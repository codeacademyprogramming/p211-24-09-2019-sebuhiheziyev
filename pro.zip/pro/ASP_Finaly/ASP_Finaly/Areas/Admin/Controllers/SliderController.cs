﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.DAL;
using ASP_Finaly.Models;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using ASP_Finaly.Extensions;
using static ASP_Finaly.Utilities.Utilities;
using Microsoft.AspNetCore.Authorization;

namespace ASP_Finaly.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]

    public class SliderController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;

        public SliderController(FrontContext context,IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Index(int page = 1)
        {
            var sliders = _context.Sliders.ToList();
            ViewData["total_slider_count"] = _context.Sliders.ToList().Count();
            ViewData["active_page"] = page;


            return View(sliders);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Slider slider)
        {
            if (!ModelState.IsValid)
            {
                return View(slider);
            }
            if (slider.Photo == null)
            {
                ModelState.AddModelError("Photo", "Sekil mutleq secilmedlir");
                return View(slider);
            }

            if (!slider.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                return View(slider);
            }
             

           

            slider.Image = await slider.Photo.SaveFileAsync(_env.WebRootPath);
            await _context.Sliders.AddAsync(slider);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Show(int? id )
        {
            if (id == null) return NotFound();

            var slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();


            return View(slider);

        }

        public async Task<IActionResult> Edit(int? id)
        {

            if (id == null) return NotFound();

            var slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();


            return View(slider);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>  Edit(int? id,Slider slider)
        {
            if (!ModelState.IsValid) return View(slider);

            Slider sliderFromDb = await _context.Sliders.FindAsync(id);

            if (slider.Photo != null)
            {
                if (slider.Photo.IsImage())
                {
                    string path = _env.WebRootPath + @"\images\" + sliderFromDb.Image;
                    RemoveFile(path);

                    sliderFromDb.Image = await slider.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                    return View(slider);
                }

            }

            sliderFromDb.Head = slider.Head;
            sliderFromDb.Content = slider.Content;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult> Delet(int? id)
        {

            if (id == null) return NotFound();

            var slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();


            return View(slider);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delet")]
        public async  Task<IActionResult> DeletPost(int? id)
        {
            if (id == null) return NotFound();

            var slider = await _context.Sliders.FindAsync(id);

            if (slider == null) return NotFound();

            string path = _env.WebRootPath + @"\images\" + slider.Image;
            RemoveFile(path);

            _context.Sliders.Remove(slider);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }
    }
}