﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.Models;
using ASP_Finaly.DAL;
using ASP_Finaly.Extensions;
using Microsoft.AspNetCore.Hosting;
using static ASP_Finaly.Utilities.Utilities;
using Microsoft.AspNetCore.Authorization;

namespace ASP_Finaly.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]

    public class ProjectsController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;

        public ProjectsController(FrontContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Index(int page = 1)
        {
            var skipCount = (int)((page - 1) * 3);
            var project = _context.Projects.OrderBy(s => s.Id).Skip(skipCount).Take(3).ToList();
            ViewData["total_project_count"] = _context.Projects.ToList().Count();
            ViewData["active_page"] = page;

            return View(project);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Project project)
        {
            if (!ModelState.IsValid)
            {
                return View(project);
            }
            if (project.Photo == null)
            {
                ModelState.AddModelError("Photo", "Sekil mutleq secilmedlir");
                return View(project);
            }

            if (!project.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                return View(project);
            }


            project.Image = await project.Photo.SaveFileAsync(_env.WebRootPath);
            await _context.Projects.AddAsync(project);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var project = await _context.Projects.FindAsync(id);

            if (project == null) return NotFound();


            return View(project);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Project project)
        {
            if (!ModelState.IsValid) return View(project);

            Project projectFromDb = await _context.Projects.FindAsync(id);

            if (project.Photo != null)
            {
                if (project.Photo.IsImage())
                {
                    string path = _env.WebRootPath + @"\images\" + projectFromDb.Image;
                    RemoveFile(path);

                    projectFromDb.Image = await project.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                    return View(project);
                }

            }

            projectFromDb.Text = project.Text;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Delet(int? id)
        {

            if (id == null) return NotFound();

            var project = await _context.Projects.FindAsync(id);

            if (project == null) return NotFound();


            return View(project);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delet")]
        public async Task<IActionResult> DeletPost(int? id)
        {
            if (id == null) return NotFound();

            var project = await _context.Projects.FindAsync(id);

            if (project == null) return NotFound();

            string path = _env.WebRootPath + @"\images\" + project.Image;
            RemoveFile(path);

            _context.Projects.Remove(project);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }
    }
}