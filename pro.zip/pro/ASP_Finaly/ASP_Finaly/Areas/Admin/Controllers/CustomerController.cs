﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.Models;
using ASP_Finaly.DAL;
using ASP_Finaly.Extensions;
using Microsoft.AspNetCore.Hosting;
using static ASP_Finaly.Utilities.Utilities;
using Microsoft.AspNetCore.Authorization;


namespace ASP_Finaly.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles ="Admin")]
    public class CustomerController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;


        public CustomerController(FrontContext context,IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Index(int page = 1)
        {
            var skipCount = (int)((page - 1) * 3);
            var customers = _context.Customers.OrderBy(s => s.Id).Skip(skipCount).Take(3).ToList();
            ViewData["total_customer_count"] = _context.Customers.ToList().Count();
            ViewData["active_page"] = page;
            

            return View(customers);
        }

        public async Task<IActionResult> Show(int? id)
        {
            if (id == null) return NotFound();

            var customer = await _context.Customers.FindAsync(id);

            if (customer == null) return NotFound();


            return View(customer);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return View(customer);
            }
            if (customer.Photo == null)
            {
                ModelState.AddModelError("Photo", "Sekil mutleq secilmedlir");
                return View(customer);
            }

            if (!customer.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                return View(customer);
            }


            customer.Image = await customer.Photo.SaveFileAsync(_env.WebRootPath);
            await _context.Customers.AddAsync(customer);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var customer = await _context.Customers.FindAsync(id);

            if (customer == null) return NotFound();


            return View(customer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Customer customer)
        {
            if (!ModelState.IsValid) return View(customer);

            Customer customerFromDb = await _context.Customers.FindAsync(id);

            if (customer.Photo != null)
            {
                if (customer.Photo.IsImage())
                {
                    string path = _env.WebRootPath + @"\images\" + customerFromDb.Image;
                    RemoveFile(path);

                    customerFromDb.Image = await customer.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                    return View(customer);
                }

            }

            customerFromDb.Name = customer.Name;
            customerFromDb.Postion = customer.Postion;
            customerFromDb.About = customer.About;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Delet(int? id)
        {

            if (id == null) return NotFound();

            var customer = await _context.Customers.FindAsync(id);

            if (customer == null) return NotFound();


            return View(customer);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delet")]
        public async Task<IActionResult> DeletPost(int? id)
        {
            if (id == null) return NotFound();

            var customer = await _context.Customers.FindAsync(id);

            if (customer == null) return NotFound();

            string path = _env.WebRootPath + @"\images\" + customer.Image;
            RemoveFile(path);

            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }
    }
}