﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASP_Finaly.Models;
using ASP_Finaly.DAL;
using ASP_Finaly.Extensions;
using Microsoft.AspNetCore.Hosting;
using static ASP_Finaly.Utilities.Utilities;
using Microsoft.AspNetCore.Authorization;

namespace ASP_Finaly.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]

    public class TeamController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;

        public TeamController(FrontContext context,IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Index(int page = 1)
        {
            var skipCount = (int)((page - 1) * 3);
            var team = _context.Teams.OrderBy(s => s.Id).Skip(skipCount).Take(3).ToList();
            ViewData["total_team_count"] = _context.Teams.ToList().Count();
            ViewData["active_page"] = page;

            return View(team);
        }

        public async Task<IActionResult> Show(int? id)
        {
            if (id == null) return NotFound();

            var team = await _context.Teams.FindAsync(id);

            if (team == null) return NotFound();


            return View(team);
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Team team)
        {
            if (!ModelState.IsValid)
            {
                return View(team);
            }
            if (team.Photo == null)
            {
                ModelState.AddModelError("Photo", "Sekil mutleq secilmedlir");
                return View(team);
            }

            if (!team.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                return View(team);
            }

            team.Image = await team.Photo.SaveFileAsync(_env.WebRootPath);
            await _context.Teams.AddAsync(team);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }

        public async  Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var team = await _context.Teams.FindAsync(id);

            if (team == null) return NotFound();


            return View(team);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Team team)
        {
            if (!ModelState.IsValid) return View(team);

            Team teamdB = await _context.Teams.FindAsync(id);

            if (team.Photo != null)
            {
                if (team.Photo.IsImage())
                {
                    string path = _env.WebRootPath + @"\images\" + teamdB.Image;
                    RemoveFile(path);

                    teamdB.Image = await team.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Sekil duzgun deyil");
                    return View(team);
                }

            }

            teamdB.Name = team.Name;
            teamdB.Postion = team.Postion;
            teamdB.About = team.About;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }



        public async Task<IActionResult> Delet(int? id)
        {

            if (id == null) return NotFound();

            var team = await _context.Teams.FindAsync(id);

            if (team == null) return NotFound();


            return View(team);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delet")]
        public async Task<IActionResult> DeletTeam(int? id)
        {
            if (id == null) return NotFound();

            var team = await _context.Teams.FindAsync(id);

            if (team == null) return NotFound();

            string path = _env.WebRootPath + @"\images\" + team.Image;
            RemoveFile(path);

            _context.Teams.Remove(team);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));

        }
    }
}