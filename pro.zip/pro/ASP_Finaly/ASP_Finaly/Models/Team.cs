﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace ASP_Finaly.Models
{
    public class Team
    {
        public int Id { get; set; }

        [StringLength(255)]
        public string Image { get; set; }

        [StringLength(50)]
        public string Name { get; set; }

        [StringLength(50)]
        public string Postion { get; set; }

        [StringLength(150)]
        public string About { get; set; }

        [StringLength(100)]
        public string Twitter { get; set; }

        [StringLength(100)]
        public string Facebook { get; set; }

        [StringLength(100)]
        public string Google { get; set; }

        [StringLength(100)]
        public string Instagram { get; set; }

        [NotMapped]
        public IFormFile Photo { get; set; }

    }
}
