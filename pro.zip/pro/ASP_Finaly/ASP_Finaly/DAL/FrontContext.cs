﻿using Microsoft.EntityFrameworkCore;
using ASP_Finaly.Models;    
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace ASP_Finaly.DAL
{
    public class FrontContext : IdentityDbContext<AppUser>
    {
        public FrontContext(DbContextOptions<FrontContext> options) : base(options)
        {
        }

        public DbSet<Slider> Sliders { get; set; }

        public DbSet<Fact> Facts { get; set; }

        public DbSet<Project> Projects { get; set; }

        public DbSet<Customer> Customers { get; set; }

        public DbSet<Team> Teams { get; set; }


    }
}
