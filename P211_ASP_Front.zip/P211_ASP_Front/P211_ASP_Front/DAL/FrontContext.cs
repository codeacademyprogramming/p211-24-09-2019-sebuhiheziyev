﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using P211_ASP_Front.Models;

namespace P211_ASP_Front.DAL
{
    public class FrontContext : IdentityDbContext<AppUser>
    {
        public FrontContext(DbContextOptions<FrontContext> options) : base(options)
        {
        }

        public DbSet<Slider> Sliders { get; set; }
        public DbSet<ShipItem> ShipItems { get; set; }
        public DbSet<Ship> Ships { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Summer> Summers { get; set; }
        public DbSet<Statics> Statics { get; set; }
        public DbSet<Subscriber> Subscribers { get; set; }
        public DbSet<Post> Posts { get; set; }
    }
}
