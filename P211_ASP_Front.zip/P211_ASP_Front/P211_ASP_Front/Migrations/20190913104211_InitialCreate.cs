﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace P211_ASP_Front.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Sliders",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    LeftVerticalText = table.Column<string>(maxLength: 100, nullable: true),
                    SupHeader = table.Column<string>(maxLength: 150, nullable: true),
                    Header = table.Column<string>(maxLength: 150, nullable: true),
                    Description = table.Column<string>(maxLength: 400, nullable: true),
                    Image = table.Column<string>(maxLength: 255, nullable: true),
                    AltImage = table.Column<string>(maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sliders", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Sliders");
        }
    }
}
