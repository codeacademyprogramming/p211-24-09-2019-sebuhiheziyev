﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace P211_ASP_Front.Models
{
    public class Slider
    {
        public int Id { get; set; }

        [StringLength(100)]
        [Display(Name = "Vertical text for the left side")]
        [Required]
        public string LeftVerticalText { get; set; }

        [StringLength(150)]
        [Required]
        [Display(Name = "Super header for slider")]
        public string SupHeader { get; set; }

        [StringLength(150)]
        [Required]
        [MinLength(10)]
        public string Header { get; set; }

        [StringLength(400)]
        [Required]
        [MinLength(20)]
        public string Description { get; set; }

        [StringLength(255)]
        public string Image { get; set; }

        [StringLength(100)]
        public string AltImage { get; set; }

        [NotMapped]
        public IFormFile Photo { get; set; }
    }
}
