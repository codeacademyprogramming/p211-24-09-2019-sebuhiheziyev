﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace P211_ASP_Front.Models
{
    public class AppUser : IdentityUser
    {
        public AppUser()
        {
            Posts = new HashSet<Post>();
        }

        [StringLength(50), MinLength(2, ErrorMessage = "Amelie deyir ki, adiniz 2-den kicik ola bilmez")]
        [Required]
        public string Firstname { get; set; }

        [StringLength(50)]
        public string Lastname { get; set; }
        public DateTime Birthdate { get; set; }

        [StringLength(255)]
        public string Image { get; set; }

        [NotMapped]
        public IFormFile MyProperty { get; set; }

        public virtual ICollection<Post> Posts { get; set; }
    }
}
