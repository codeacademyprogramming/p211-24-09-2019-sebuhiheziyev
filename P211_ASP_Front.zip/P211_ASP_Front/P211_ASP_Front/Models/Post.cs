﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace P211_ASP_Front.Models
{
    public class Post
    {
        public int Id { get; set; }

        [StringLength(200)]
        [Required]
        [MinLength(4)]
        public string Header { get; set; }

        [Required]
        [MinLength(20)]
        public string Content { get; set; }

        [StringLength(255)]
        public string Image { get; set; }
        public DateTime CreatedAt { get; set; }

        [StringLength(450)]
        public string AppUserId { get; set; }

        public virtual AppUser AppUser { get; set; }

        [NotMapped]
        [Required]
        public IFormFile Photo { get; set; }
    }
}
