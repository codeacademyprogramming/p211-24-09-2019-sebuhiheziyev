﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace P211_ASP_Front.Models
{
    public class Product
    {
        public int Id { get; set; }
        [StringLength(255)]
        public string Image { get; set; }
        [StringLength(50)]
        public string Name { get; set; }
        public decimal Price { get; set; }
        public bool HasDiscount { get; set; }
        public decimal DiscountPrice { get; set; }
        public int Rating { get; set; }
        public DateTime CreatedAt { get; set; }

        public static implicit operator BasketProduct(Product product)
        {
            return new BasketProduct
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                HasDiscount = product.HasDiscount,
                DiscountPrice = product.DiscountPrice,
                Image = product.Image,
                Quantity = 1
            };
        }
    }
}
