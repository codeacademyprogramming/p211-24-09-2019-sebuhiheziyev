﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using P211_ASP_Front.Models;
using P211_ASP_Front.ViewModels;
using System.Threading.Tasks;
using System.Linq;

namespace P211_ASP_Front.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class UsersController : Controller
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<AppUser> _userManager;
        public UsersController(RoleManager<IdentityRole> roleManager, UserManager<AppUser> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            ViewData["active_nav"] = "users";
            return View(_userManager.Users);
        }

        public async Task<IActionResult> Edit(string id)
        {
            if (id == null) return NotFound();

            AppUser user = await _userManager.FindByIdAsync(id);

            if (user == null) return NotFound();

            ViewData["active_nav"] = "users";
            return View(user);
        }

        public async Task<IActionResult> Delete(string userid, string role)
        {
            if (userid == null || role == null) return NotFound();

            AppUser user = await _userManager.FindByIdAsync(userid);

            if (user == null) return NotFound();

            await _userManager.RemoveFromRoleAsync(user, role);

            return RedirectToAction(nameof(Edit), new { id = userid });
        }

        public async Task<IActionResult> AddRole(string id)
        {
            if (id == null) return NotFound();

            AppUser user = await _userManager.FindByIdAsync(id);

            if (user == null) return NotFound();

            var userRoles = (await _userManager.GetRolesAsync(user)).ToList();
            var allRoles = _roleManager.Roles.Select(r => r.Name).ToList();

            UserAddRoleVM vm = new UserAddRoleVM
            {
                AppUser = user,
                Roles = allRoles.Except(userRoles)
            };

            ViewData["active_nav"] = "users";
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddRole(string id, string role)
        {
            if (id == null) return NotFound();

            AppUser user = await _userManager.FindByIdAsync(id);

            if (user == null) return NotFound();

            var result = await _userManager.AddToRoleAsync(user, role);

            if(result.Succeeded)
            {
                return RedirectToAction(nameof(Index), new { id = id });
            }

            return RedirectToAction(nameof(AddRole), new { id = id });
        }
    }
}