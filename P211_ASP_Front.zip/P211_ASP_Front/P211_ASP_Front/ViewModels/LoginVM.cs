﻿using System.ComponentModel.DataAnnotations;

namespace P211_ASP_Front.ViewModels
{
    public class LoginVM
    {
        [Required(ErrorMessage = "Email doldurulmalidir")]
        [MinLength(5)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public bool RememberMe { get; set; }
    }
}
