﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace P211_ASP_Front.ViewModels
{
    public class RegisterVM
    {
        [Required(ErrorMessage = "Email doldurulmalidir")]
        [MinLength(5)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Username doldurulmalidir")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Ad doldurulmalidir")]
        [MinLength(3)]
        public string Firstname { get; set; }

        public string Lastname { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required, Compare(nameof(Password))]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}
