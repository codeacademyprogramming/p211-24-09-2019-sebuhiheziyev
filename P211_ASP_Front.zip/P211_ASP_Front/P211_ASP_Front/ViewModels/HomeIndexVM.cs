﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using P211_ASP_Front.Models;

namespace P211_ASP_Front.ViewModels
{
    public class HomeIndexVM
    {
        public IEnumerable<Slider> Sliders { get; set; }
        public Ship Ship { get; set; }

        public IEnumerable<Product> Products { get; set; }

        public Summer  Summers { get; set; }

        public IEnumerable<Statics> Statics { get; set; }
    }

}
