﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using P211_ASP_Front.Models;

namespace P211_ASP_Front.ViewModels
{
    public class ProductPartialVM
    {
        public IEnumerable<Product> Products { get; set; }
        public string ClassName { get; set; }
    }
}
