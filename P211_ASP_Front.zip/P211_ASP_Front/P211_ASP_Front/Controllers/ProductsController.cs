﻿using Microsoft.AspNetCore.Mvc;
using P211_ASP_Front.DAL;
using System.Linq;

namespace P211_ASP_Front.Controllers
{
    public class ProductsController : Controller
    {
        private readonly FrontContext _context;

        public ProductsController(FrontContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var products = _context.Products.OrderByDescending(p => p.CreatedAt).Take(6);
            ViewData["total_products"] = _context.Products.Count();

            return View(products);
        }
    }
}