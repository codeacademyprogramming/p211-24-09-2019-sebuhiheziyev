﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P211_ASP_Front.DAL;
using P211_ASP_Front.Models;
using P211_ASP_Front.Extensions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;

namespace P211_ASP_Front.Controllers
{
    public class ProfileController : Controller
    {
        private readonly FrontContext _context;
        private readonly IHostingEnvironment _env;
        private readonly UserManager<AppUser> _userManager;

        public ProfileController(FrontContext context, IHostingEnvironment env, UserManager<AppUser> userManager)
        {
            _context = context;
            _env = env;
            _userManager = userManager;
        }

        public IActionResult CreatePost()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePost(Post post)
        {
            if (!ModelState.IsValid) return View(post);

            if(post.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected");
                return View(post);
            }

            if (!post.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Photo should be image type");
                return View(post);
            }

            post.Image = await post.Photo.SaveFileAsync(_env.WebRootPath);
            post.CreatedAt = DateTime.Now;

            AppUser activeUser = await _userManager.FindByNameAsync(User.Identity.Name);
            post.AppUserId = activeUser.Id;

            await _context.Posts.AddAsync(post);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Posts");
        }
    }
}