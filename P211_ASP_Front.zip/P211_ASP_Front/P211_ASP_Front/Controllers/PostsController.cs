﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using P211_ASP_Front.DAL;
using P211_ASP_Front.Models;
using System.Linq;
using System.Threading.Tasks;

namespace P211_ASP_Front.Controllers
{
    public class PostsController : Controller
    {
        private readonly FrontContext _context;
        private readonly UserManager<AppUser> _userManager;

        public PostsController(FrontContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [Route("Posts/Index/{username?}")]
        public async Task<IActionResult> Index(string username = null)
        {
            //eager loading
            //lazy loading
            if(username != null)
            {
                AppUser user = await _userManager.FindByNameAsync(username);

                if(user != null)
                {
                    return View(_context.Posts.Where(p => p.AppUserId == user.Id).OrderByDescending(p => p.CreatedAt));
                }
            }

            return View(_context.Posts.OrderByDescending(p => p.CreatedAt));
        }

    }
}