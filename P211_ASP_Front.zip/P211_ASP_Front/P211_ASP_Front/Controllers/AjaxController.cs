﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P211_ASP_Front.DAL;
using P211_ASP_Front.Models;
using P211_ASP_Front.ViewModels;

namespace P211_ASP_Front.Controllers
{
    public class AjaxController : Controller
    {
        private readonly FrontContext _context;

        public AjaxController(FrontContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Subscribe(string email)
        {
            if(_context.Subscribers.Any(s => s.Email == email))
            {
                return Ok(new {
                    status = 410,
                    data = "",
                    message = "Email exists"
                });
            }

            await _context.Subscribers.AddAsync(new Subscriber { Email = email });
            await _context.SaveChangesAsync();

            return Ok(new
            {
                status = 200,
                data = "",
                message = "Email was added"
            });
        }

        public IActionResult LoadProducts(int skip)
        {   
            return PartialView("_ProductPartialView", new ProductPartialVM {
                Products = _context.Products.OrderByDescending(p => p.CreatedAt).Skip(skip).Take(3),
                ClassName = "col-lg-4 col-md-6"
            });
        }
    }
}