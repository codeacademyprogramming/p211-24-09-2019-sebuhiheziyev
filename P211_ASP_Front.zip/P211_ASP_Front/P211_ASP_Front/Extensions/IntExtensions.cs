﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P211_ASP_Front.Extensions
{
    public static class IntExtensions
    {
        public static int FindPower(this int b, int power)
        {
            int result = 1;

            for (int i = 0; i < power; i++)
            {
                result *= b;
            }

            return result;
        }
    }
}
