﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace P211_ASP_Front.Extensions
{
    public static class IFormFileExtensions
    {
        public static async Task<string> SaveFileAsync(this IFormFile file, string webRootPath)
        {
            string uniqueId = Guid.NewGuid().ToString();
            string newFileName = uniqueId + file.FileName;
            string path = webRootPath + @"\image\" + newFileName;

            using (FileStream fs = new FileStream(path, FileMode.Create))
            {
                await file.CopyToAsync(fs);
            }

            return newFileName;
        }

        public static bool IsImage(this IFormFile file)
        {
            return file.ContentType.Contains("image/");
        }
    }
}
