﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace P211_ASP_Front.Utilities
{
    public static class Utilities
    {
        public static void RemoveFile(string file, string webrootpath)
        {
            string path = webrootpath + @"\image\" + file;

            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }
    }
}
